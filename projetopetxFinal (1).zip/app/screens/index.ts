export * from "./home/home-screen"
export * from "./veterinario/veterinario-list-screen"
export * from "./veterinario/veterinario-form-create-screen"
export * from './cliente/cliente-list-screen'
export * from './cliente/cliente-form-create-screen'
export * from './pet/pet-list-screen'
export * from './pet/pet-form-create-screen'
export * from './pet/pet-form-edit-screen'
export * from './cliente/client-form-edit-screen'
export * from '../screens/veterinario/veterinario-form-edit-screen'
export * from './servico/servico-list-screen'
export * from './servico/servico-form-create-screen'
export * from './servico/servico-form-edit-screen'
export * from './passeador/passeador-form-create-screen'
export * from './passeador/passeador-form-edit-screen'
export * from './passeador/passeador-list-screen'
export * from './tosador/tosador-form-create-screen'
export * from './tosador/tosador-form-edit-screen'
export * from './tosador/tosador-list-screen'




// export other screens here
